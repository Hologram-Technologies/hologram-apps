# Hologram OS console sign-in gate. Only the initial *root* console boot is gated;
# the holo login shell (uid 1000) and every nested shell fall straight through.
if [ "$(id -u)" = 0 ] && [ -z "${HOLO_GATED:-}" ] && [ -t 0 ]; then
  export HOLO_GATED=1
  exec /bin/bash --noprofile --norc /etc/holo-login
fi
